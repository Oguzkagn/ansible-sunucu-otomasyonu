Klasörün içindeki dosyaları bilgisayarınızda bir klasöre çıkartınız.Hedef makinede Ansible aracılığıyla kullanıcı oluşturma,nginx kurma,
servis başlatma,web sayfasına aktarma,paket yükleme gibi işlemleri yapmak için gerekli playbooklar dosyanın içeriğinde bulunmaktadır.
.sh uzantılı script dosyasını çalıştırarak bu işlemleri daha rahat şekilde yapabilirsiniz.

ÖNEMLİ!!!!!

Hedef makinelerinizin ip'sini inventory.ini dosyasındaki iplerle değiştirmeniz gerekmektedir.Ayrıca hedef makineler playbookları çalıştırırken
açık durumda olmalıdır.Aksi takdirde playbooklar hedef makineye ulaşamaz ve istediğiniz işlemi gerçekleştiremezsiniz.
